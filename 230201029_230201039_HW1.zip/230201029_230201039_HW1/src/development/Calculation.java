/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Calculation {
	
	private int presentYear; //For compute vehicle's age.
	
	public Calculation(){
		setPresentYear(2017);
	}
	
	public double calculate(Vehicle vehicle, Company company){
		
		int vehicleAge = presentYear - vehicle.getProducedYear();
		
		double yearCost;
		double hpCost;
		double accidentCost;
		
		switch(vehicle.getType()){
		case CAR:
			yearCost = 1000 / (Math.pow(2, vehicleAge));
			hpCost = vehicle.getHorsePower() * 10;
			if(vehicleAge < 3)
				accidentCost = vehicle.getAccidentpenalty() * 200;
			else
				accidentCost = vehicle.getAccidentpenalty() * 100;
			break;
		case BUS:
			yearCost = 2000 / (Math.pow(2, vehicleAge));
			hpCost = vehicle.getHorsePower() * 10;
			if(vehicleAge < 5)
				accidentCost = vehicle.getAccidentpenalty() * 400;
			else
				accidentCost = vehicle.getAccidentpenalty() * 200;
			break;
		case MOTORCYCLE:
			yearCost = 500 / (Math.pow(2, vehicleAge));
			hpCost = vehicle.getHorsePower() * 3;
			if(vehicleAge < 1)
				accidentCost = vehicle.getAccidentpenalty() * 100;
			else
				accidentCost = vehicle.getAccidentpenalty() * 50;
			break;
		default:
			System.out.println("Warning! Vehicle type not found!");
			yearCost = 0;
			hpCost= 0;
			accidentCost = 0;
			break;
			
		}
		
		double insuranceCost = (yearCost * company.getWeightX()) + (hpCost * company.getWeightY()) + (accidentCost * company.getWeightZ());
		return insuranceCost;
	}

	public void setPresentYear(int presentYear){//For later purposes.
		this.presentYear = presentYear;
	}

	public int getPresentYear() {
		return presentYear;
	}

}
