/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public enum VehicleType {
	CAR,
	BUS,
	MOTORCYCLE,
}
