/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;

public class CompanyApp {

	public static void main(String[] args) {
		
		FileParser data = new FileParser();
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		
		vehicleList = data.readFile();
		
		Calculation defaultOption = new Calculation(); //I defined it default option because it is calculating results for already known companies.
		
		for(int i = 0; i < vehicleList.size(); i++){
			
			Vehicle eachVehicle = vehicleList.get(i);
			
			char dolar = '\u0024'; //Sweet!
			
			System.out.println("CompanyA offering " + defaultOption.calculate(eachVehicle, new Company(CompanyName.CompanyA)) + 
					dolar + " for " + eachVehicle.getOwner() + "'s " + eachVehicle.getType() + ".");
			System.out.println("CompanyB offering " + defaultOption.calculate(eachVehicle, new Company(CompanyName.CompanyB)) + 
					dolar + " for " + eachVehicle.getOwner() + "'s " + eachVehicle.getType() + ".");
			System.out.println("CompanyC offering " + defaultOption.calculate(eachVehicle, new Company(CompanyName.CompanyC)) + 
					dolar + " for " + eachVehicle.getOwner() + "'s " + eachVehicle.getType() + "." + "\n");
			//Even though test files are important, our main target to compute every company's offer for every owner.
		}
		
	}

}

