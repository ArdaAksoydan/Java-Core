/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Vehicle {
	
	private String owner;
	private String brand;
	private int producedYear;
	private int horsePower;
	private double accidentPenalty;
	private VehicleType type;
	
	public Vehicle(String owner, String brand, int producedYear, int horsePower, double accidentPenalty, VehicleType type){
		if(owner != null){
			this.owner = owner;}
		else{
			this.owner = "NO NAME GIVEN";
		}
		if(brand != null){
			this.brand = brand;}
		else{
			this.brand = "NO BRAND GIVEN";
		}
		if(producedYear > 0){
			this.producedYear = producedYear;}
		else{
			this.producedYear = 2017;
		}
		if (horsePower > 0){
			this.horsePower = horsePower;}
		else{
			this.horsePower = 0;
		}
		if(accidentPenalty >= 0.0 && accidentPenalty <= 1.0){
			this.accidentPenalty = accidentPenalty;}
		else{
			this.accidentPenalty = 1.0;
		}
		if(type == VehicleType.CAR || type == VehicleType.BUS || type == VehicleType.MOTORCYCLE){
			this.type = type;}
		else{
			this.type = VehicleType.CAR;
		}
	}

	public String getBrand() {
		return brand;
	}

	public String getOwner() {
		return owner;
	}

	public int getProducedYear() {
		return producedYear;
	}

	public int getHorsePower() {
		return horsePower;
	}

	public double getAccidentpenalty() {
		return accidentPenalty;
	}

	public VehicleType getType() {
		return type;
	}

	@Override
	public String toString() {
		return "Vehicle [owner=" + getOwner() + ", brand=" + getBrand() + ", producedyear=" + getProducedYear() + ", housepower="+ getHorsePower() + ", accidentpenalty=" + getAccidentpenalty() + ", type=" + getType() + "]";
	}
	
}
