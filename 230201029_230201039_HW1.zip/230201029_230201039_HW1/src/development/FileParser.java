/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class FileParser {	
		
	private Scanner file;
	private ArrayList<Vehicle> vehicleList;
		
	public FileParser() {
		vehicleList = new ArrayList<Vehicle>();
	}
		
	public ArrayList<Vehicle> readFile() {
		
		file = null;
			
		try{
			file = new Scanner(new File("vehicles.dat"));//Actually I gave this as an argument to method to increase readability but whatever...
														 //#obeythetestfiles
			while(file.hasNextLine()){
					
				String line = file.nextLine();
				StringTokenizer stringTokenizer = new StringTokenizer(line, ",");
					
				while(stringTokenizer.hasMoreTokens()){
						
					String owner = stringTokenizer.nextToken().trim();
					String brand = stringTokenizer.nextToken().trim();
					String produced_str = stringTokenizer.nextToken().trim();
					String horsePower_str = stringTokenizer.nextToken().trim();//Just for caution...
					String accidentPenalty_str = stringTokenizer.nextToken().trim();
					String type_str =stringTokenizer.nextToken().trim();
						
					int producedYear = Integer.parseInt(produced_str);
					int horsePower = Integer.parseInt(horsePower_str);
					double accidentPenalty = Double.parseDouble(accidentPenalty_str);
					VehicleType type;
						
					switch (type_str) {
						case "Car":
							type = VehicleType.CAR;
							break;
						case "Bus":
							type = VehicleType.BUS;
							break;
						case "Motorcycle":
							type = VehicleType.MOTORCYCLE;
							break;
						default:
							type = VehicleType.BUS;
							System.out.println("Warning! Read file error!");//In any case...
							System.exit(0);
							break;
						}
					
						Vehicle newVehicle = new Vehicle(owner, brand, producedYear, horsePower, accidentPenalty, type);
						vehicleList.add(newVehicle);
					}
				}
			}catch(FileNotFoundException e){
				e.getMessage();
				System.exit(0);
			}
			return vehicleList;
		}

}