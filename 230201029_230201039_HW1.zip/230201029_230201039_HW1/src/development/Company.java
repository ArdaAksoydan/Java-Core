/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Company {
	
	private double weightX;
	private double weightY;
	private double weightZ;
	
	public Company(double weightX, double weightY, double weightZ){
		if(weightX > 0 ){
			this.weightX = weightX;
		}
		else{
			this.weightX = 1.0;
		}
		if(weightY > 0 ){
			this.weightY = weightY;
		}
		else{
			this.weightY = 1.0;
		}
		if(weightZ > 0 ){
			this.weightZ = weightZ;
		}
		else{
			this.weightZ = 1.0;
		}
	}
	
	public Company(CompanyName companyName){//This is a special constructor for CompanyA, CompanyB and CompanyC.
		switch(companyName){
		case CompanyA:
			this.weightX =  0.7;
			this.weightY = 0.3;
			this.weightZ =  0.3;
			break;
		case CompanyB:
			this.weightX = 0.3;
			this.weightY = 0.3;
			this.weightZ = 0.4;
			break;
		case CompanyC:
			this.weightX =  0.2;
			this.weightY =  0.2;
			this.weightZ = 0.6;
			break;
		default:
			System.out.println("Warning! Company not found!");
			this.weightX =  1.0;
			this.weightY =  1.0;
			this.weightZ = 1.0;
			break;
		}
	}
	
	public double getWeightX() {
		return weightX;
	}

	public double getWeightY() {
		return weightY;
	}

	public double getWeightZ() {
		return weightZ;
	}

	@Override
	public String toString() {
		return "Company [weightX=" + getWeightX() + ", weightY=" + getWeightY() + ", weightZ=" + getWeightZ() + "]";
	}
	
}

