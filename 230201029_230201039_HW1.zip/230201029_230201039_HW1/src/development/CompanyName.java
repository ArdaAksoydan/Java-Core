/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public enum CompanyName {//Founders of these companies weren't creative people, I guess.
	CompanyA,
	CompanyB,
	CompanyC,
}
