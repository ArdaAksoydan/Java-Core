/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

public interface ICustomerListAnalytics {
	
	int getNumberOfFemaleCustomers();
	int getNumberOfMaleCustomers();
	int getNumberOfSeniorCustomers();
	int getNumberOfAdultCustomers();
	int getNumberOfYoungCustomers();
	boolean add(Customer customer);//Added for TestCustomerList class.
	
}