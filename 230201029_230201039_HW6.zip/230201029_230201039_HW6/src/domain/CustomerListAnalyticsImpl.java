/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.ArrayList;
import java.util.List;

public class CustomerListAnalyticsImpl implements ICustomerListAnalytics{

	private List<Customer> customerList;
	
	public CustomerListAnalyticsImpl(){
		this.customerList = new ArrayList<Customer>();
	}
	
	public boolean add(Customer customer){
		if(customer != null){
			customerList.add(customer);
			return true;
		}
		else
			return false;
			
	}

	public int getNumberOfFemaleCustomers() {
		int numberOfFemaleCustomers = 0;
		
		for (Customer customer: customerList){
			if(customer.getGender() == 'F' || customer.getGender() == 'f')
				numberOfFemaleCustomers++;
		}
		return numberOfFemaleCustomers;
	}


	public int getNumberOfMaleCustomers() {
		int numberOfMaleCustomers = 0;
		
		for (Customer customer: customerList){
			if(customer.getGender() == 'M' || customer.getGender() == 'm')
				numberOfMaleCustomers++;
		}
		return numberOfMaleCustomers;
	}


	public int getNumberOfSeniorCustomers() {
		int numberOfSeniorCustomers = 0;
		
		for(Customer customer: customerList){
			if(customer.getType() == Type.Senior)
				numberOfSeniorCustomers++;
		}
		return numberOfSeniorCustomers;
	}


	public int getNumberOfAdultCustomers() {
		int numberOfAdultCustomers = 0;
		
		for(Customer customer: customerList){
			if(customer.getType() == Type.Adult)
				numberOfAdultCustomers++;
		}
		return numberOfAdultCustomers;
	}

	public int getNumberOfYoungCustomers() {
		int numberOfYoungCustomers = 0;
		
		for(Customer customer: customerList){
			if(customer.getType() == Type.Young)
				numberOfYoungCustomers++;
		}
		return numberOfYoungCustomers;
	}

	@Override
	public String toString() {
		return "CustomerListImpl [buyers=" + customerList + "]";
	}
	
}