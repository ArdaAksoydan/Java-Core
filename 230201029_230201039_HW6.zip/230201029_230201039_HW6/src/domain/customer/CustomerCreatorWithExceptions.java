/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain.customer;

import domain.Customer;

public class CustomerCreatorWithExceptions extends Customer{
	
	public CustomerCreatorWithExceptions() {
		super();
	}

	public CustomerCreatorWithExceptions(String name, int age, char gender) {
		super(name, age, gender);
	}

	public Customer createCustomer(int customerAge, char customerGender, String customerName){
		
		Customer customer;
	
		if(customerAge < 18 || customerAge > 79)
			throw new IllegalArgumentException("Invalid Age Parameter");
		else if (Character.toUpperCase(customerGender) != 'M' && Character.toUpperCase(customerGender) != 'F')//customerGender still not changed since taken as argument.
			throw new IllegalArgumentException("Invalid Gender Parameter");
		else if(customerName == null || customerName.length() > 20)
			throw new IllegalArgumentException("Invalid Name Parameter! Name can not be null or longer than 20 char");
		else
			customer = new CustomerCreatorWithExceptions(customerName, customerAge, customerGender);
		
		return customer;
	}

}