/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

public abstract class Customer {
	
	private String name;
	private int age;
	private char gender;//I really wanted to make gender enum type as Gender gender but testToString in TestCustomerList gave me no choice.
	private Type type;
	
	public Customer(){
		this.name = "Customer";
		this.age = 30;
		this.gender = 'M';
		this.type = Type.Adult;
	}

	public Customer(String name, int age, char gender) {
		this.name = name;
		this.age = age;
		this.gender = gender;
		
		if(age >= 18 && age <= 29)
			this.type = Type.Young;
		else if(age >= 30 && age <= 59)
			this.type = Type.Adult;
		else
			this.type = Type.Senior;
	}
	

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public char getGender() {
		return gender;
	}
	
	public Type getType(){
		return type;
	}

	@Override
	public String toString() {
		return "" + getType() + " [super=Customer [age=" + getAge() + ", gender=" + getGender() + ", name=" + getName() + ", type=" + getType() + "]]";
	}

}