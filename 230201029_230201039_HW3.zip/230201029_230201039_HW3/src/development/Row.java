/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;

public class Row {
	
	private ArrayList<Cell> cells = new ArrayList<Cell>();

	public Row(ArrayList<Cell> cells) {
		this.cells = cells;
	}

	public void setCells(ArrayList<Cell> cells) {//So test cases don't mind to set null but give error to return null? Interesting...
			this.cells = cells;
	}

	public ArrayList<Cell> getCells() {
		if (cells == null)
			System.out.println("Given cells cannot be null!");
		return cells;
	}

	@Override
	public String toString() {
		return "Row [cells=" + cells + "]";
	}
	
}
