/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;
import java.util.Random;

public class Game {//So game doesn't know his/her player? Interesting...
	
	private Grid grid;
	Random random = new Random();

	public Game(Grid grid) {
		this.grid = grid;
	}
	
	public Game(){
		setGrid(null);
	}
	
	public void start(Player player){
		
		setGrid(createGrid());
		
		int gridSize = grid.getRows().size();
		
		player.setCurrentCell(grid.getRows().get(gridSize - 1).getCells().get(gridSize - 1));//Game starts on right bottom.
		player.setCurrentRow(grid.getRows().get(gridSize - 1));
		
		int row = gridSize - 1;
		int column = gridSize - 1;
		Movement lastMovement = null;//Algorithm saver attribute, right there...
		boolean gameContinues = true;
		
		showGrid(player, row, column);
		
		int numberOfMovement = 0;
		int restartMeter = 0;
		
		while(gameContinues){
			if(play(Movement.LEFT, player) && lastMovement != Movement.RIGHT){
				move(Movement.LEFT, player, row ,column);
				column = column - 1;
				lastMovement = Movement.LEFT;
				numberOfMovement++;
				if(player.getCurrentCell().getLeft() == CellComponents.EXIT){
					System.out.println("Game over! Agent has escaped!");
					gameContinues = false;}		
			}
			else if(play(Movement.UP, player) && lastMovement != Movement.DOWN){
				move(Movement.UP, player, row, column);
				row = row - 1;
				lastMovement = Movement.UP;
				numberOfMovement++;
				if(player.getCurrentCell().getLeft() == CellComponents.EXIT){
					System.out.println("Game over! Agent has escaped!");
					gameContinues = false;}	
			}
			else if(play(Movement.DOWN, player) && lastMovement != Movement.UP){
				move(Movement.DOWN, player, row, column);
				row = row + 1;
				lastMovement = Movement.DOWN;
				numberOfMovement++;
				if(player.getCurrentCell().getLeft() == CellComponents.EXIT){
					System.out.println("Game over! Agent has escaped!");
					gameContinues = false;}	
			}
			else if(play(Movement.RIGHT, player) && lastMovement != Movement.LEFT){
				move(Movement.RIGHT, player, row, column);
				column = column + 1;
				lastMovement = Movement.RIGHT;
				numberOfMovement++;
			}
			else{
				player.setCurrentCell(grid.getRows().get(gridSize - 1).getCells().get(gridSize - 1));
				player.setCurrentRow(grid.getRows().get(gridSize - 1));
				System.out.println("Agent returned starting point.");
				
				row = gridSize - 1;
				column = gridSize - 1;//I wrote this only for the first time if agent stuck in left instead of going up.
				restartMeter++;
				showGrid(player, row, column);
				
				move(Movement.UP, player, row, column);
				row = row - 1;
				numberOfMovement++;
				showGrid(player, row, column);
				
			}
			if (numberOfMovement > 40){
				System.out.println("Agent moved so many times and realized he/she is moving in circles. Game Over!");
				gameContinues = false;}
			if (restartMeter > 2){
				System.out.println("Agent moved " + numberOfMovement + " times and now stuck in labyrinth. Game Over!");
				gameContinues = false;//Since labyrinth is created totaly random, there are strong odds there is no proper exit in labyrinth. Sorry Agent!
			}
				
			showGrid(player, row, column);
		}
	}

	public void setGrid(Grid grid) {
		this.grid = grid;
	}

	public Grid getGrid() {
		if (this.grid == null)
			System.out.println("Given grid cannot be null!");
		return grid;
	}
	
	public Grid createGrid(){//Kinda hard to track, please read slowly...
		
		ArrayList<Row> labyrinth = new ArrayList<Row>();
		
		int gridSize = random.nextInt(5) + 3;//Between 3 and 7.
		
		for (int i = 0; i < gridSize; i++){
			
			ArrayList <Cell> cells = new ArrayList<Cell>();
			
			for (int j = 0; j < gridSize; j++){
				
				CellComponents up = null;
				CellComponents down = null;
				CellComponents left = null;
				CellComponents right = null;
				
				if (i == 0){
					up = CellComponents.WALL;}
				if (j == 0){
					left = CellComponents.WALL;}//Boundaries matter...
				if (i == gridSize - 1){
					down = CellComponents.WALL;}
				if (j == gridSize - 1){
					right = CellComponents.WALL;}
					
				int numberOfAperture = random.nextInt(2);//For the number of aperture in a cell.
				int k = 0;
				
				while(k <= numberOfAperture){
					
					int placeOfAperture = random.nextInt(4);//For the place of aperture in a cell.
						
					if (placeOfAperture == 0 && up != CellComponents.WALL){
						up = CellComponents.APERTURE;
						k++;}
					else if(placeOfAperture == 1 && left != CellComponents.WALL){//Every cell has at least one aperture, I don't know why test case giving error...
						left = CellComponents.APERTURE;
						k++;}
					else if(placeOfAperture == 2 && right != CellComponents.WALL){
						right = CellComponents.APERTURE;
						k++;}
					else if(placeOfAperture == 3 && down != CellComponents.WALL){
						down = CellComponents.APERTURE;
						k++;}
				}
				
				Cell cell = new Cell(left,right,up,down);
		
				cell.setDown(down);
				cell.setRight(right);//No null value anymore.
				cell.setLeft(left);
				cell.setUp(up);
				
				cells.add(cell);
				
			}
			
			Row row = new Row(cells);
			labyrinth.add(i, row);
			
			}
		
			for (int i = gridSize - 1; i >= 0; i--){//Now, all cells open to each other.
				for (int j = gridSize -1; j >= 0; j--){
					
					if(labyrinth.get(i).getCells().get(j).getLeft() == CellComponents.APERTURE)
						labyrinth.get(i).getCells().get(j-1).setRight(CellComponents.APERTURE);
						
					if(labyrinth.get(i).getCells().get(j).getUp() == CellComponents.APERTURE)
						labyrinth.get(i-1).getCells().get(j).setDown(CellComponents.APERTURE);
					
				}
				
			}
		
			int placeOfExit = random.nextInt(gridSize);
			
			labyrinth.get(placeOfExit).getCells().get(0).setLeft(CellComponents.EXIT);//Only one exit concluded.
			
			Grid gameGrid = new Grid(labyrinth);
			
			return gameGrid;
	}
	
	public void showGrid(Player player,int row, int column){
		
		int gridSize = this.grid.getRows().size();
		
		char[][] grid = new char[gridSize][gridSize];//All this project would be WAY easier if we used two dimensional array but it's too late now...
		
		for(int i = 0; i < grid.length;i++){
			for(int j = 0; j < grid[i].length;j++){
				if(this.grid.getRows().get(i).getCells().get(j).getLeft() == CellComponents.EXIT)
					grid[i][j] = 'E';
				else
					grid[i][j] = 'S';
			}
		}
		
		grid[row][column] = 'A';
		
		for(int i = 0; i < grid.length;i++){
			for(int j = 0; j < grid[i].length;j++){
				if( j == gridSize -1)
					System.out.print(grid[i][j] + "\n");
				else
					System.out.print(grid[i][j] + "  ");
				}
			}
		System.out.println();
	}
	
	public boolean play(Movement movement, Player player){
		if(player.getCurrentCell().getLeft() == CellComponents.APERTURE && movement == Movement.LEFT)
			return true;
		else if(player.getCurrentCell().getUp() == CellComponents.APERTURE && movement == Movement.UP)
			return true;
		else if(player.getCurrentCell().getDown() == CellComponents.APERTURE && movement == Movement.DOWN)
			return true;
		else if(player.getCurrentCell().getRight() == CellComponents.APERTURE && movement == Movement.RIGHT)
			return true;
		else
			return false;
	}
	
	private void move(Movement movement, Player player, int row, int column){//It will move when I said so...
		if(movement == Movement.UP){
			player.setCurrentRow(grid.getRows().get(row - 1));
			player.setCurrentCell(grid.getRows().get(row - 1).getCells().get(column));
			}
		else if(movement == Movement.LEFT){
			player.setCurrentRow(grid.getRows().get(row));
			player.setCurrentCell(grid.getRows().get(row).getCells().get(column - 1));
		}
		else if(movement == Movement.RIGHT){
			player.setCurrentRow(grid.getRows().get(row));
			player.setCurrentCell(grid.getRows().get(row).getCells().get(column + 1));
		}
		else{
			player.setCurrentRow(grid.getRows().get(row + 1));
			player.setCurrentCell(grid.getRows().get(row + 1).getCells().get(column));
		}
		
	}
	
	@Override
	public String toString() {
		return "Game [grid=" + grid + "]";
	}

}
