/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;

public class Grid {
	
	private ArrayList<Row> rows = new ArrayList<Row>();

	public Grid(ArrayList<Row> rows) {
		this.rows = rows;
	}

	public void setRows(ArrayList<Row> rows) {
		this.rows = rows;
	}

	public ArrayList<Row> getRows() {
		if(this.rows == null)
			System.out.println("Given rows cannot be null!");
		return rows;
	}

	@Override
	public String toString() {
		return "Grid [rows=" + rows + "]";
	}
	
}
