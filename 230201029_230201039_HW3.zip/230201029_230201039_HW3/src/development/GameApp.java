/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class GameApp {

	public static void main(String[] args) {
		
		Player agent = new Player();
		Game letMeOut = new Game();
		letMeOut.start(agent);
		
	}

}
