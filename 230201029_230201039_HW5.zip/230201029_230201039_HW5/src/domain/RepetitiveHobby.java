/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.GregorianCalendar;

public class RepetitiveHobby extends RepetitiveActivity implements Hobby {
	
	public RepetitiveHobby(String name, GregorianCalendar startingDate){
		super(name,startingDate);
	}

	@Override
	public void postpone(GregorianCalendar newStartingDate) {
		setStartingDate(newStartingDate);
		calculateActiveDates(getRoutine());
		setStatus(Status.PENDING);
	}
}