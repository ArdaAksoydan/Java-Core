/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class RepetitiveActivity extends Activity {
	
	private Routine routine;
	private int specifiedRoutine;
	
	public RepetitiveActivity(String name, GregorianCalendar startingDate) {
		super(name, startingDate);
		@SuppressWarnings("resource")				//Closes at ToDo class
		Scanner scan = new Scanner(System.in);
		//for routine
		this.routine = null;
		while(routine == null) {
			System.out.println("What will be the frequency of this activity ?\n"
																	+ "1)Daily\n"
																	+ "2)Weekly\n"
																	+ "3)Monthly\n"
																	+ "4)Other");
			String choice = scan.nextLine();
			if (choice.equalsIgnoreCase("daily") || choice.equals("1")) 
				this.routine = Routine.DAILY;
			else if (choice.equalsIgnoreCase("weekly") || choice.equals("2"))
				this.routine = Routine.WEEKLY;
			else if (choice.equalsIgnoreCase("monthly") || choice.equals("3"))
				this.routine = Routine.MONTHLY;
			else if (choice.equalsIgnoreCase("other") || choice.equals("4")) {
				this.routine = Routine.OTHER;
				System.out.println("Please enter the specific frequency in day format(such as 3 for once in three days)");
				this.specifiedRoutine = Integer.parseInt(scan.nextLine());
			}
			else
				System.out.println("Invalid input, please enter one of the options as its number or name\n");
		}
		//for finishingDate
		System.out.println("Would you like to define a deadline ? (in dd/mm/yyyy format)\n! Warning : If you don't enter a deadline, it will be automatically on end of this year");
		String deadline = scan.nextLine();
		String[] tokenizedWordArray = deadline.split("/");
		try {
			GregorianCalendar tempDate = new GregorianCalendar(Integer.parseInt(tokenizedWordArray[2]), Integer.parseInt(tokenizedWordArray[1])-1, Integer.parseInt(tokenizedWordArray[0]));
			setFinishingDate(tempDate);
		} catch(Exception e){
			System.out.println("Invalid date, default value will be initialized.\n");
			GregorianCalendar tempDate = new GregorianCalendar(startingDate.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			setFinishingDate(tempDate);
		}
		//for activeDates
		calculateActiveDates(routine);
	}
	
	public void calculateActiveDates(Routine routine) {
		ArrayList<GregorianCalendar> tempDateList = new ArrayList<GregorianCalendar>();
		GregorianCalendar tempDate = (GregorianCalendar) getStartingDate().clone();			//for counting and iterating
		while(tempDate.before(getFinishingDate())) {
			if (routine.equals(Routine.DAILY)) {
				GregorianCalendar nextTempDate = (GregorianCalendar) tempDate.clone();
				tempDateList.add(nextTempDate);
				tempDate.add(Calendar.DAY_OF_MONTH, 1);
			}
			else if(routine.equals(Routine.WEEKLY)){
				GregorianCalendar nextTempDate = (GregorianCalendar) tempDate.clone();
				tempDateList.add(nextTempDate);
				tempDate.add(Calendar.WEEK_OF_MONTH, 1);
			}
			else if(routine.equals(Routine.MONTHLY)) {
				GregorianCalendar nextTempDate = (GregorianCalendar) tempDate.clone();
				tempDateList.add(nextTempDate);
				tempDate.add(Calendar.MONTH, 1);
			}
			else if(routine.equals(Routine.OTHER)) {
				GregorianCalendar nextTempDate = (GregorianCalendar) tempDate.clone();
				tempDateList.add(nextTempDate);
				tempDate.add(Calendar.DAY_OF_MONTH, specifiedRoutine);				
			}
		}
		setActiveDates(tempDateList);
	}
	
	public Routine getRoutine() {
		return routine;
	}

	public void setRoutine(Routine routine) {
		this.routine = routine;
	}

	public int getSpecifiedRoutine() {
		return specifiedRoutine;
	}

	public void setSpecifiedRoutine(int specifiedRoutine) {
		this.specifiedRoutine = specifiedRoutine;
	}

	@Override
	public String toString() {
		return "RepetitiveActivity [routine=" + routine + ", specifiedRoutine=" + specifiedRoutine + "]";
	}
	
}