/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class SingleHobby extends SingleActivity implements Hobby {
	
	public SingleHobby(String name, GregorianCalendar startingDate){
		super(name,startingDate);
	}

	@Override
	public void postpone(GregorianCalendar newStartingDate) {
		setStartingDate(newStartingDate);
		ArrayList<GregorianCalendar> tempDateList = new ArrayList<GregorianCalendar>();
		tempDateList.add(newStartingDate);
		setActiveDates(tempDateList);
		setStatus(Status.PENDING);
	}
	
}