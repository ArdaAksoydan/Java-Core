/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class Activity {
	
	private String name;
	private Status status;
	private GregorianCalendar startingDate;
	private ArrayList<GregorianCalendar> activeDates;
	private GregorianCalendar finishingDate;
	
	public Activity(String name, GregorianCalendar startingDate) {
		this.name = name;
		GregorianCalendar today = new GregorianCalendar();
		if (startingDate.before(today))
			this.status = Status.STARTED;
		else
			this.status = Status.PENDING;
		this.startingDate = startingDate;
		this.activeDates = new ArrayList<GregorianCalendar>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public GregorianCalendar getStartingDate() {
		return startingDate;
	}

	public void setStartingDate(GregorianCalendar startingDate) {
		this.startingDate = startingDate;
	}

	public ArrayList<GregorianCalendar> getActiveDates() {
		return activeDates;
	}

	public void setActiveDates(ArrayList<GregorianCalendar> activeDates) {
		this.activeDates = activeDates;
	}

	public GregorianCalendar getFinishingDate() {
		return finishingDate;
	}

	public void setFinishingDate(GregorianCalendar finishingDate) {
		this.finishingDate = finishingDate;
	}

	@Override
	public String toString() {
		return "Activity [name=" + name + ", status=" + status + "]";
	}
	
}