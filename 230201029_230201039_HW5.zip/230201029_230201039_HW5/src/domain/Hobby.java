/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.GregorianCalendar;

public interface Hobby {
	
	public void postpone(GregorianCalendar startingDate);
	
}