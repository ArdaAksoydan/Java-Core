/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package domain;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class SingleActivity extends Activity {
	
	private Routine routine;
	
	public SingleActivity(String name, GregorianCalendar startingDate) {
		super(name, startingDate);
		this.routine = Routine.ONCE;
		setFinishingDate(startingDate);
		ArrayList<GregorianCalendar> tempDateList = new ArrayList<GregorianCalendar>();
		tempDateList.add(startingDate);
		setActiveDates(tempDateList);
	}

	public Routine getRoutine() {
		return routine;
	}

	public void setRoutine(Routine routine) {
		this.routine = routine;
	}

	@Override
	public String toString() {
		return "SingleActivity [routine=" + routine + "]";
	}
	
}