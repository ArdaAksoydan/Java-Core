/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package presentation;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Scanner;

import domain.*;

public class ToDo {
	
	private ArrayList<Activity> activities;
	
	public ToDo(){
		activities = new ArrayList<Activity>();
	}
	
	public void start(){
		System.out.println("Welcome to ToDo! App");
		System.out.println("--------------------");
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while(flag) {
			System.out.println(	"Press\n"
								+"1)Add Activity\n"
								+"2)Delete Activity\n"
								+"3)View Activities\n"
								+"4)Exit");
			String choice = sc.nextLine();
			if (choice.equals("1")) {
				System.out.println("Activity name: ");
				String activityName = sc.nextLine();
				System.out.println("Starting date in (dd/mm/yyyy): ");
				String activityStartingDateString = sc.nextLine();
				String[] tokenizedWordArray = activityStartingDateString.split("/");
				GregorianCalendar activityStartingDate = new GregorianCalendar(Integer.parseInt(tokenizedWordArray[2]), Integer.parseInt(tokenizedWordArray[1])-1, Integer.parseInt(tokenizedWordArray[0]));
				System.out.println(	"What kind of Activity,\n"
									+ "1)Mandatory and Once\n"
									+ "2)Mandatory and Repetitive\n"
									+ "3)Hobby and Once\n"
									+ "4)Hobby and Repetitive");
				choice = sc.nextLine();
				if (choice.equals("1"))
					addActivity(new SingleActivity(activityName, activityStartingDate));
				else if (choice.equals("2"))
					addActivity(new RepetitiveActivity(activityName, activityStartingDate));
				else if (choice.equals("3"))
					addActivity(new SingleHobby(activityName, activityStartingDate));
				else if (choice.equals("4"))
					addActivity(new RepetitiveHobby(activityName, activityStartingDate));
			}
			else if(choice.equals("2")) {
				System.out.println("Activity name: ");
				String activityName = sc.nextLine();
				deleteActivity(activityName);
			}
			else if(choice.equals("3")) {
				System.out.println("Date in (dd/mm/yyyy): ");
				String activityStartingDateString = sc.nextLine();
				viewActivitiesOn(activityStartingDateString);
			}
			else if(choice.equals("4"))
				flag = false;
		}
		sc.close();
	}
	
	public void addActivity(Activity activity) {
		activities.add(activity);
		System.out.println(activity.getName()+" added");
	}
	
	public void deleteActivity(String name) {
		boolean flag = true;
		for (Activity k : activities) {
			if (name.equalsIgnoreCase(k.getName())) {
				activities.remove(k);
				System.out.println(k.getName()+" deleted.");
				flag = false;
				break;
			}
		}
		if (flag)
			System.out.println(name+" is not in on ToDo list");
	}
	
	public void viewActivitiesOn(String date) {			//in dd/mm/yyyy form
		ArrayList<Activity> tempActivities = new ArrayList<Activity>();
		String[] tokenizedWordArray = date.split("/");
		GregorianCalendar tempDate = new GregorianCalendar(Integer.parseInt(tokenizedWordArray[2]), Integer.parseInt(tokenizedWordArray[1])-1, Integer.parseInt(tokenizedWordArray[0]));
		for (Activity i : activities) {
			for (GregorianCalendar j : i.getActiveDates()) {
				if (j.equals(tempDate))
					tempActivities.add(i);
			}
		}
		System.out.println(date);
		System.out.println("----------");
		for(Activity i : tempActivities) {
			System.out.println("Name: "+i.getName());
			if (tempDate.after(i.getFinishingDate()))
				System.out.println("Status: "+Status.DONE);
			else
				System.out.println("Status: "+Status.STARTED);
			System.out.println("o---o");
		}
		if (tempActivities.isEmpty())
			System.out.println("No activity");
		System.out.println("----------");
	}
}