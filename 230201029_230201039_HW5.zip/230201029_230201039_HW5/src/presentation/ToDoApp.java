/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package presentation;

public class ToDoApp {

	public static void main(String[] args) {
		
		ToDo toDo = new ToDo();
		toDo.start();
	
	}

}