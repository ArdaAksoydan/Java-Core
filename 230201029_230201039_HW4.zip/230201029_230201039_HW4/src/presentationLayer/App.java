//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package presentationLayer;

public class App {

	public static void main(String[] args) {
		Screen gui = new Screen();
	}
}