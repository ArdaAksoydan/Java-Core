//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package presentationLayer;

import dataAccessLayer.*;
import domainLayer.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.*;

public class Screen extends JFrame implements ActionListener{
	private Person person;
	private Meal meal;
	private Nutrition nutrition;
	
	private JButton okButton,cancelButton,addButton;
	private JTextField userName,userAge,userWeight,userHeight;
	private ButtonGroup genderChoices,mealChoices;
	
	Screen(){
		super("Diet Application");
		
		JPanel panel = new JPanel(new BorderLayout());
		JPanel namePanel = new JPanel(new FlowLayout());
		JPanel agePanel = new JPanel(new FlowLayout());
		JPanel weightPanel = new JPanel(new FlowLayout());
		JPanel heightPanel = new JPanel(new FlowLayout());
		JPanel genderPanel = new JPanel(new FlowLayout());
		
		this.okButton = new JButton("OK");
		this.cancelButton = new JButton("Cancel");
		okButton.addActionListener((ActionListener) this);
		cancelButton.addActionListener((ActionListener) this);
		
		JLabel name = new JLabel("Enter your name:");
		this.userName = new JTextField(30);
		
		JLabel age = new JLabel("Enter your age:");
		this.userAge = new JTextField(2);
		
		JLabel weight = new JLabel("Enter your weight:");
		this.userWeight = new JTextField(3);
		
		JLabel height = new JLabel("Enter your height:");
		this.userHeight = new JTextField(3);
		
		JLabel gender = new JLabel("Select your gender:");
		JRadioButton userGenderMale = new JRadioButton("Male");
		JRadioButton userGenderFemale = new JRadioButton("Female");
		this.genderChoices = new ButtonGroup();
		genderChoices.add(userGenderMale);
		genderChoices.add(userGenderFemale);
		
		namePanel.add(name);
		namePanel.add(userName);
		
		agePanel.add(age);
		agePanel.add(userAge);
		
		weightPanel.add(weight);
		weightPanel.add(userWeight);
		
		heightPanel.add(height);
		heightPanel.add(userHeight);
		
		genderPanel.add(gender);
		genderPanel.add(userGenderMale);
		genderPanel.add(userGenderFemale);
		genderPanel.add(okButton);
		genderPanel.add(cancelButton);
		
		panel.add(namePanel,BorderLayout.NORTH);
		panel.add(agePanel,BorderLayout.WEST);
		panel.add(weightPanel,BorderLayout.CENTER);
		panel.add(heightPanel,BorderLayout.EAST);
		panel.add(genderPanel,BorderLayout.SOUTH);
		add(panel);

		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	//For Radio Button Selection
    public String getSelectedButtonText(ButtonGroup buttonGroup) {
        for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();

            if (button.isSelected()) {
                return button.getText();
            }
        }

        return null;
    }
    public JTable createTable(Object[][] nutritionArray){
    	String[] columnNames = {"Name","Gr","Cal"};
    	Object[][] data = nutritionArray;
    	JTable table = new JTable(data,columnNames);
    	return table;
    }
    
    public void createSecondFrame() {
    	JFrame frame = new JFrame("Diet Application");
    	
    	JPanel mainPanel = new JPanel(new BorderLayout());
    	JPanel rightPanel = new JPanel(new BorderLayout());
    	JPanel leftPanel = new JPanel(new BorderLayout());
    	JPanel leftDownPanel = new JPanel(new BorderLayout());
    	JPanel leftUpPanel = new JPanel(new BorderLayout());
    	
    	FileTokenizer tokenizer = new FileTokenizer("nutrition.dat");
    	FileModifier modifier = new FileModifier(tokenizer.getNutritionList());
    	//JTable nutritionTable = createTable(modifier.getNutritionArray());
    	
    	
    	JLabel userInfo = new JLabel("User: "+this.person.toString());
    	
    	this.addButton = new JButton("Add");
    	addButton.addActionListener((ActionListener) this);
    	JRadioButton breakfastChoice = new JRadioButton("Breakfast");
    	JRadioButton lunchChoice = new JRadioButton("Lunch");
    	JRadioButton dinnerChoice = new JRadioButton("Dinner");
    	this.mealChoices = new ButtonGroup();
    	mealChoices.add(breakfastChoice);
    	mealChoices.add(lunchChoice);
    	mealChoices.add(dinnerChoice);
    	
    	leftUpPanel.add(breakfastChoice,BorderLayout.NORTH);
    	leftUpPanel.add(lunchChoice,BorderLayout.CENTER);
    	leftUpPanel.add(dinnerChoice,BorderLayout.SOUTH);
    	leftDownPanel.add(addButton);
    	leftPanel.add(leftUpPanel,BorderLayout.NORTH);
    	leftPanel.add(leftDownPanel,BorderLayout.SOUTH);
    	//rightPanel.add(nutritionTable.getTableHeader(),BorderLayout.NORTH);
    	//rightPanel.add(nutritionTable,BorderLayout.SOUTH);
    	mainPanel.add(userInfo,BorderLayout.NORTH);
    	mainPanel.add(leftPanel,BorderLayout.WEST);
    	mainPanel.add(rightPanel,BorderLayout.EAST);
    	frame.add(mainPanel);
    	
    	frame.pack();
    	frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    	frame.setLocationRelativeTo(null);
    	frame.setVisible(true);
    }
	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource().equals(okButton)) {
			String name = userName.getText();
			double weight = Double.parseDouble(userWeight.getText());
			double height = Double.parseDouble(userHeight.getText());
			int age = Integer.parseInt(userAge.getText());
			Gender gender;
			if(getSelectedButtonText(genderChoices).equals("Male")){
				gender = Gender.MALE;
			}else{
				gender = Gender.FEMALE;
			}
			this.person = new Person(name,weight,height,age,gender);
			dispose();
			createSecondFrame();
		}else if (ae.getSource().equals(cancelButton)) {
			dispose();
		}else if(ae.getSource().equals(addButton)) {
			JOptionPane.showMessageDialog(null, "ADDED");
		}
	}
}