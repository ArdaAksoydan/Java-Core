//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public enum Gender {
	MALE,
	FEMALE
}