//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public enum NutritionType {
	CEREAL,
	MEATS,
	DAIRYPRODUCTS,
	FRUITS,
	FISH,
	VEGETABLES
}