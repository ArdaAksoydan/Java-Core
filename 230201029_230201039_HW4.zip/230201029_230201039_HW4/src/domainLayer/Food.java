//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public class Food extends Nutrition{
	
	private double unitInGr;
	private final NutritionPhysicalType nutritionPhysicalType = NutritionPhysicalType.FOOD;
	
	public Food(String name, double unitInGr, double calorie, NutritionType nutritionType) {
		super(name, calorie, nutritionType);
		this.unitInGr = unitInGr;
	}

	public double getUnitInGr() {
		return unitInGr;
	}

	public NutritionPhysicalType getNutritionPhysicalType() {
		return nutritionPhysicalType;
	}

	@Override
	public String toString() {
		return "Food [" + super.toString() + "unitInGr=" + unitInGr + "nutritionPhysicalType=" + nutritionPhysicalType + "]";
	}
	
}