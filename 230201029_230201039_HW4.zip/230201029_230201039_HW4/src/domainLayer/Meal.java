//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

import java.util.ArrayList;

public abstract class Meal {
	
	private ArrayList<Nutrition> nutritionList;
	private double totalCalorie;
	
	public Meal(ArrayList<Nutrition> nutritionList) {
		this.nutritionList = nutritionList;
		computeTotalCalorie(nutritionList);
		}
	
	public void computeTotalCalorie(ArrayList<Nutrition> nutritionList){
		double calorie = 0;
		for(Nutrition nutrition : nutritionList){
			calorie = calorie + nutrition.getCalorie();
		}
		this.totalCalorie = calorie;
	}

	public ArrayList<Nutrition> getNutritionList() {
		return nutritionList;
	}

	public double getTotalCalorie() {
		return totalCalorie;
	}
	
}