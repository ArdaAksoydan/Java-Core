//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public abstract class Nutrition {
	
	private String name;
	private double calorie;
	private NutritionType nutritionType;
	
	public Nutrition(String name, double calorie, NutritionType nutritionType) {
		this.name = name;
		this.calorie = calorie;
		this.nutritionType = nutritionType;
	}

	public String getName() {
		return name;
	}

	public double getCalorie() {
		return calorie;
	}

	public NutritionType getNutritionType() {
		return nutritionType;
	}

	@Override
	public String toString() {
		return "Nutrition [name=" + name + ", calorie=" + calorie + ", nutritionType=" + nutritionType + "]";
	}

}