//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

import java.util.ArrayList;

public class Lunch extends Meal{
	
	private final NutritionType[] nutritionTypes = {NutritionType.MEATS, NutritionType.FRUITS, NutritionType.VEGETABLES};
	
	public Lunch(ArrayList<Nutrition> nutritionList) {
		super(nutritionList);
	}

	public NutritionType[] getNutritionTypes() {
		return nutritionTypes;
	}	

}