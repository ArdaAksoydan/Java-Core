//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public class Person {
	
	private String name;
	private double weight;
	private double height;
	private int age;
	private Gender gender;
	private double totalDailyCalorie;
	
	public Person(String name, double weight, double height, int age, Gender gender){
		this.name = name;
		this.weight = weight;
		this.height = height;
		this.age = age;
		this.gender = gender;
		setTotalDailyCalorie(weight, height, age, gender);
	}
	
	public void setTotalDailyCalorie(double weight, double height, int age, Gender gender){
		if(gender == Gender.MALE)
			this.totalDailyCalorie = (10*weight) + (6.25*height) - (5*age) + 5;
		else
			this.totalDailyCalorie = (10*weight) + (6.25*height) - (5*age) - 161;
	}

	public String getName() {
		return name;
	}

	public double getWeight() {
		return weight;
	}

	public double getHeight() {
		return height;
	}

	public int getAge() {
		return age;
	}

	public Gender getGender() {
		return gender;
	}

	public double getTotalDailyCalorie() {
		return totalDailyCalorie;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", weight=" + weight + ", height=" + height + ", age=" + age + ", gender="
				+ gender + ", totalDailyCalorie=" + totalDailyCalorie + "]";
	}
	
}