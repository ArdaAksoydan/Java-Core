//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

public class Drink extends Nutrition{
	
	private double unitInMl;
	private final NutritionPhysicalType nutritionPhysicalType = NutritionPhysicalType.DRINK;
	
	public Drink(String name, double unitInMl, double calorie, NutritionType nutritionType) {
		super(name, calorie, nutritionType);
		this.unitInMl = unitInMl;
	}

	public double getUnitInMl() {
		return unitInMl;
	}

	public NutritionPhysicalType getNutritionPhysicalType() {
		return nutritionPhysicalType;
	}
	
	@Override
	public String toString() {
		return "Drink [" + super.toString() + "unitInMl=" + unitInMl + "nutritionPhysicalType=" + nutritionPhysicalType + "]";
	}

}