//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package domainLayer;

import java.util.ArrayList;

public class Breakfast extends Meal{
	
	private final NutritionType[] nutritionTypes = {NutritionType.CEREAL, NutritionType.DAIRYPRODUCTS, NutritionType.FRUITS, NutritionType.VEGETABLES};
	
	public Breakfast(ArrayList<Nutrition> nutritionList) {
		super(nutritionList);
	}
	
	public NutritionType[] getNutritionTypes() {
		return nutritionTypes;
	}
	
}