//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package dataAccessLayer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JOptionPane;

public class FileTokenizer {
	private String fileName;
	private ArrayList<String> nutritionList;
	
	public FileTokenizer(String fileName) {
		this.fileName = fileName;
		this.nutritionList = new ArrayList<String>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String line = reader.readLine();
			while(line != null) {
				String[] tokenizedLine = line.split(",");
				nutritionList.addAll(Arrays.asList(tokenizedLine));
				line = reader.readLine();
			}
			reader.close();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "The file you trying to reach cannot be found");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "The file you trying to reach cannot be opened");
		}
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public ArrayList<String> getNutritionList() {
		return nutritionList;
	}
	public void setNutritionList(ArrayList<String> nutritionList) {
		this.nutritionList = nutritionList;
	}
	@Override
	public String toString() {
		return "FileParser [fileName=" + fileName + ", nutritionList=" + nutritionList + "]";
	}
}
