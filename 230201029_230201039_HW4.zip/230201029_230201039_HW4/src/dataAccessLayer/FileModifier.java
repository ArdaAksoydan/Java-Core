//Mehmet Arda Aksoydan 230201029 - H�seyin Berk G�k 230201039

package dataAccessLayer;

import java.util.ArrayList;

public class FileModifier {
	private ArrayList<String> nutritionArrayList;
	
	public FileModifier(ArrayList<String> nutritionList) {
		this.nutritionArrayList = nutritionList;
	}
	public String[][] toStringArray(){
		int row = nutritionArrayList.size()/5;
		int column = 5;
		String[][] nutritionArray = new String[row][column];
		int j = 0;
		for (int i = 0 ; i<nutritionArrayList.size() ; i=i+5) {
			for(int k = 0 ; k< column ; k++) {
				nutritionArray[j][k]=nutritionArrayList.get(i+k);
			}
			j++;
		}
		return nutritionArray;
	}
	
	public ArrayList<String> getNutritionArrayList() {
		return nutritionArrayList;
	}
	public void setNutritionArrayList(ArrayList<String> nutritionArrayList) {
		this.nutritionArrayList = nutritionArrayList;
	}
}
