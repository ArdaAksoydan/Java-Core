/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Student {

	private String studentID;
	private String studentName;
	private University university;
	private DepartmentName department;
	private Thesis thesis;
	private Advisor advisor;
	
	public Student(String studentID, String studentName, University university,DepartmentName department) {
		if(studentID != null)
			this.studentID = studentID;
		else
			this.studentID = "NO STUDENT ID GIVEN";
		if(studentName != null)
			this.studentName = studentName;
		else
			this.studentName = "NO STUDENT NAME GIVEN";
		this.university = university;
		this.department = department;
	}
	
	public void setThesis(Thesis thesis) {
		this.thesis = thesis;
	}

	public void setAdvisor(Advisor advisor) {
		this.advisor = advisor;
	}

	public String getStudentID() {
		return studentID;
	}

	public String getStudentName() {
		return studentName;
	}

	public University getUniversity() {
		return university;
	}

	public DepartmentName getDepartment() {
		return department;
	}

	public Thesis getThesis() {
		return thesis;
	}

	public Advisor getAdvisor() {
		return advisor;
	}

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studentName=" + studentName + ", university=" + university
				+ ", department=" + department + ", thesis=" + thesis + ", advisor=" + advisor + "]";
	}

}
