/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class CalculationApp {

	public static void main(String[] args) {
		
		Calculation calculation = new Calculation("genealogy.xml");
		calculation.start();
	}

}
