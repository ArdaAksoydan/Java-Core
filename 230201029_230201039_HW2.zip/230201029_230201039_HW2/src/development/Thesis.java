/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Thesis {
	
	private String thesisName;
	private Student student;
	private University university;
	private int publishedYear;
	private Advisor advisor;

	public Thesis(String thesisName, Student student, University university, int publishedYear) {
		if(thesisName.contains("UNTITLED"))
			this.thesisName = "NO THESIS NAME GIVEN";
		else
			this.thesisName = thesisName;
		this.student = student;
		this.university = university;
		if(publishedYear > 0)
			this.publishedYear = publishedYear;
		else
			this.publishedYear = 0;		//to understand that publishedYear is invalid
	}

	public void setAdvisor(Advisor advisor) {
		this.advisor = advisor;
	}

	public String getThesisName() {
		return thesisName;
	}

	public Student getStudent() {
		return student;
	}

	public University getUniversity() {
		return university;
	}

	public int getPublishedYear() {
		return publishedYear;
	}

	public Advisor getAdvisor() {
		return advisor;
	}

	@Override
	public String toString() {
		return "Thesis [thesisName=" + thesisName + ", publishedYear=" + publishedYear + "]";
	}
	
}
