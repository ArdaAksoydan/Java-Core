/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class University {
	
	private String universityName;
	private int foundationYear;
	private String universityCountry;
	
	public University(String universityName, int foundationYear, String universityCountry) {
		if(universityName != null)
			this.universityName = universityName;
		else
			this.universityName = "NO UNIVERSITY NAME GIVEN";
		if(foundationYear > 0)
			this.foundationYear = foundationYear;
		else
			this.foundationYear = 0;		//to understand that foundationYear is invalid
		if(universityCountry != null)
			this.universityCountry = universityCountry;
		else
			this.universityCountry = "NO COUNTRY GIVEN";
	}

	public String getUniversityName() {
		return universityName;
	}

	public int getFoundationYear() {
		return foundationYear;
	}

	public String getUniversityCountry() {
		return universityCountry;
	}

	@Override
	public String toString() {
		return "University [universityName=" + universityName + ", foundationYear=" + foundationYear
				+ ", universityCountry=" + universityCountry + "]";
	}
	
}
