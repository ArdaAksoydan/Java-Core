/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DataAccessLayer {
	
	private ArrayList<Student> studentList;//Even though I can make a list with data types advisor or thesis, I believe student is enough.
	
	public DataAccessLayer(){
		this.studentList = new ArrayList<Student>();
	}
	
	public ArrayList<Student> getStudentList(String input) {//Designed for xml type datas.

	      try {
	    	 File inputFile = new File(input);
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         NodeList nodeList = doc.getElementsByTagName("Advisor");
	         
	         for (int i = 0; i < nodeList.getLength(); i++) {
	            
	        	 Node node = nodeList.item(i);
	            
	            
	            if (node.getNodeType() == Node.ELEMENT_NODE) {
	            	
	               Element element = (Element) node;
	               
	               String advisorName = element.getAttribute("name");
	               
	               NodeList subNodes = node.getChildNodes();
	               
	               Node firstSubNode = subNodes.item(1);
	               
	               
	               Element firstElement = (Element) firstSubNode;
	               
	               String studentName = firstElement.getAttribute("name");
	               String studentID = firstElement.getAttribute("id");
	               
	               NodeList secondSubNodes = firstSubNode.getChildNodes();
	               
	               Node secondSubNode = secondSubNodes.item(1);
	               
	               
	               Element secondElement = (Element) secondSubNode;
	               
	               String thesisName = secondElement.getAttribute("name");
	 	           String thesisYear_str = secondElement.getAttribute("year");
	 	           int thesisYear = Integer.parseInt(thesisYear_str);
	 	               
	 	           Node thirdSubNode = secondSubNodes.item(3);
	 	           
	 	          
	 	           Element thirdElement = (Element) thirdSubNode;
	 	          
	 	           String universityName = thirdElement.getAttribute("name");
	 	           String foundationYear_str = thirdElement.getAttribute("foundedYear");
	 	           int foundationYear = Integer.parseInt(foundationYear_str);
	 	           String universityCountry = thirdElement.getAttribute("country");
	               
	 	           Node fourthSubNode = secondSubNodes.item(5);
	 	          
	 	           Element fourthElement = (Element) fourthSubNode;
	 	          
	 	           String departmentName = fourthElement.getAttribute("name");
	 	           DepartmentName departmentType;
	 	           
	 	           switch(departmentName){
	 	           case "COMPUTER_SCIENCE":
	 	        	   departmentType = DepartmentName.COMPUTER_SCIENCE;
	 	        	   break;
	 	           case "PHYSICS":
	 	        	   departmentType = DepartmentName.PHYSICS;
	 	        	   break;
	 	           case "MATHEMATICS":
	 	        	   departmentType = DepartmentName.MATH;
	 	        	   break;
	 	           case "CHEMISTRY":
	 	        	   departmentType = DepartmentName.CHEMISTRY;
	 	        	   break;
	 	           default:
	 	        	   departmentType = DepartmentName.COMPUTER_SCIENCE;
	 	        	   break;
	 	           }
	 	           
	 	           
	 	           University university = new University(universityName,foundationYear,universityCountry);
	 	      
	 	           Student student = new Student(studentID, studentName, university, departmentType);
	 	           
	 	           Thesis thesis = new Thesis(thesisName, student, university, thesisYear);
	 	           
	 	           student.setThesis(thesis);
	 	           
	 	           Advisor advisor = new Advisor(advisorName, thesis, university);
	 	           
	 	           student.setAdvisor(advisor);//One by one, piece by piece...
	 	           
	 	           advisor.setStudent(student);
	 	           
	 	           thesis.setAdvisor(advisor);
	 	           
	 	           studentList.add(student);
	            
	            }
	         }
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return studentList;
	   }
	
}
