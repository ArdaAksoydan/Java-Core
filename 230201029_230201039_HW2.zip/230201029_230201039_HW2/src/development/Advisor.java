/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

public class Advisor {
	
	private String advisorName;
	private Thesis thesis;
	private University university;
	private Student student;
	
	public Advisor(String advisorName, Thesis thesis, University university) {
		if(advisorName != null)
			this.advisorName = advisorName;
		else
			this.advisorName = "NO ADVISOR NAME GIVEN";
		this.thesis = thesis;
		this.university = university;
	}
	
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public Student getStudent() {
		return student;
	}

	public String getAdvisorName() {
		return advisorName;
	}
	
	public Thesis getThesis() {
		return thesis;
	}

	public University getUniversity() {
		return university;
	}

	@Override
	public String toString() {
		return "Advisor [advisorName=" + advisorName + "]";
	}
	
}