/*
 * 
 *@author M. Arda Aksoydan - H. Berk G�k, 230201029 - 230201039
 *
 */

package development;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Calculation {//Probably good name for a data class.
	private ArrayList<Student> dataList;
	private Scanner scanner;
	
	public Calculation(String dataFile){
		DataAccessLayer data = new DataAccessLayer();
		this.dataList = data.getStudentList(dataFile);
		this.scanner = new Scanner(System.in);
	}
	
	public void start(){//One method to execute them all...
		int point = 1;
		String answer;
		
		System.out.println("Welcome! Please type the number you want.");
		
		while (point != 0){
			
			System.out.println("----------Menu----------");
			System.out.println("1.List all thesis by university and department");
			System.out.println("2.List all academicians that are both advisor and student");
			System.out.println("3.List all thesis in chronological order by advisor");
			System.out.println("4. Find the country that has the most number of published theses");
			System.out.println("5.Listing all universities by advisor");
			System.out.println("Press anything else for exit.");
			
			point = scanner.nextInt();
			
			scanner.nextLine();//nextInt() in scanner is little tricky...
			
			switch(point){
			case 1:
				System.out.println("Name of University");
				String universityName = scanner.nextLine();
				System.out.println("Name of Department");
				String departmentName = scanner.nextLine();
				DepartmentName departmentType;
				switch(departmentName){
	 	           case "COMPUTER_SCIENCE":
	 	        	   departmentType = DepartmentName.COMPUTER_SCIENCE;
	 	        	   break;
	 	           case "PHYSICS":
	 	        	   departmentType = DepartmentName.PHYSICS;
	 	        	   break;
	 	           case "MATHEMATICS":
	 	        	   departmentType = DepartmentName.MATH;
	 	        	   break;
	 	           case "CHEMISTRY":
	 	        	   departmentType = DepartmentName.CHEMISTRY;
	 	        	   break;
	 	           default:
	 	        	   departmentType = DepartmentName.COMPUTER_SCIENCE;
	 	        	   break;
	 	           }
				sortByDepartment(universityName, departmentType);
				
				System.out.println("Return to menu? [Y/n]");
				answer = scanner.next();
				
				if(answer.equals("Y"))
					continue;
				else
					point = 0;
				break;
			case 2:
				showAdvisorAndStudent();
				
				System.out.println("Return to menu? [Y/n]");
				answer = scanner.next();
				
				if(answer.equals("Y"))
					continue;
				else
					point = 0;
				break;
			
			case 3:
				System.out.println("Name of Advisor");
				String advisorName = scanner.nextLine();
				
				sortByAdvisor(advisorName);
				
				System.out.println("Return to menu? [Y/n]");
				answer = scanner.next();
				
				if(answer.equals("Y"))
					continue;
				else
					point = 0;
				break;
				
			case 4:
				findTopCountry();
				
				System.out.println("Return to menu? [Y/n]");
				answer = scanner.next();
				
				if(answer.equals("Y"))
					continue;
				else
					point = 0;
				break;
			
			case 5:
				System.out.println("Name of Advisor/Student");
				String advisorStudentName = scanner.nextLine();
				
				findUniversitiesByAdvisor(advisorStudentName);
				
				System.out.println("Return to menu? [Y/n]");
				answer = scanner.next();
				
				if(answer.equals("Y"))
					continue;
				else
					point = 0;
				break;
				
			default:
				point = 0;
				break;
			}
		}
		scanner.close();
	}

	public void sortByDepartment(String universityName, DepartmentName departmentType){
		ArrayList<Student> secondaryList = new ArrayList<Student>();
		
		for(Student student: dataList){
			if(student.getUniversity().getUniversityName().equals(universityName) && student.getDepartment() == departmentType)
				secondaryList.add(student);
		}
		for(Student student: secondaryList){
			System.out.println(student.getThesis());
		}
		if(secondaryList.size() == 0)
			System.out.println("Student with the university name " + universityName + " and department name " + departmentType + " couldn't found.");
	}
	
	public void showAdvisorAndStudent(){
		ArrayList<String> secondaryList = new ArrayList<String>();
		
		for(int i = 0; i < dataList.size(); i++){
			Student student1 = dataList.get(i);
			for(int j = 1; j < dataList.size(); j++){
				Student student2 = dataList.get(j);
					if(student1.getAdvisor().getAdvisorName().equals(student2.getStudentName()))
						secondaryList.add(student2.getStudentName());
				}
			}
		secondaryList.sort(String::compareToIgnoreCase);
		
		System.out.println(secondaryList.get(0));
		
		for(int i = 1; i < secondaryList.size(); i++){
			if(!secondaryList.get(i-1).equals(secondaryList.get(i)))
				System.out.println(secondaryList.get(i));
		}
		if(secondaryList.size() == 0)
			System.out.println("Student/Advisor who is both couldn't found.");
	}
	
	public void sortByAdvisor(String advisorName){
		ArrayList<Student> secondaryList = new ArrayList<Student>();
		
		for(Student student: dataList){
			if(student.getAdvisor().getAdvisorName().equals(advisorName))
				secondaryList.add(student);
		}
		
		Student temp = null;
		
		for(int i = 0; i < secondaryList.size(); i++){
			Student student1 = secondaryList.get(i);
			for(int j = 1; j < secondaryList.size();j++){
				Student student2 = secondaryList.get(j);
				if(student1.getThesis().getPublishedYear() > student2.getThesis().getPublishedYear())
					temp = student1;
					student1 = student2;//Selection sort, best sort! (Not really, actually...)
					student2 = temp;
			}
		}
		for(Student student: secondaryList){
			System.out.println(student.getThesis());
		}
		if(secondaryList.size() == 0)
			System.out.println("Student who has advisor with the name " + advisorName + " couldn't found.");
		}
	
	public void findTopCountry(){
		ArrayList<String> countryList = new ArrayList<String>();
		
		for (Student student: dataList){
			countryList.add(student.getUniversity().getUniversityCountry());
		}
		
		countryList.sort(String::compareToIgnoreCase);//I miss Python...
		
		int firstCount = Collections.frequency(countryList, countryList.get(0));//Good thing we have internet, right?
		String topCountry = countryList.get(0);
		int secondCount = 0;
		
		for(int i = 1; i < countryList.size(); i++){
			if(!countryList.get(i-1).equals(countryList.get(i)))
				secondCount = Collections.frequency(countryList, countryList.get(i));
				if(secondCount > firstCount){
					firstCount = secondCount;
					topCountry = countryList.get(i);
				}
		}
		
		System.out.println(topCountry + " has the most published thesis with " + firstCount + " published thesis.");
	}
	
	public void findUniversitiesByAdvisor(String advisorName){
		ArrayList<Student> secondaryList = new ArrayList<Student>();
		
		for(Student student: dataList){//I wonder if anyone reading these comments...
			if(student.getAdvisor().getAdvisorName().equals(advisorName)){
				secondaryList.add(student);
			}
			else if(student.getStudentName().equals(advisorName))//Maybe he/she was student before, who knows?
				secondaryList.add(student);
		}
		
		for(Student student: secondaryList){
			System.out.println(student.getUniversity());
		}
		
		if(secondaryList.size() == 0){
			System.out.println("Advisor/Student with the name " + advisorName + " couldn't found.");
		}
	}
	
}